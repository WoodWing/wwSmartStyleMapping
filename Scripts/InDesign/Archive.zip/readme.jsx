// 
// 
// The scripts in this folder will be pushed to the EnterpriseScripts folder in 
// the InDesign User Scripts folder when a user with applicable access rights logs in 
// into Enterprise 
//
// This InDesign folder should contain all scripts (subfolders, such as 'Startup Scripts' 
// allowed). The scripts must be compressed into a Scripts.zip file. The plug-in uses
// datetime of the Scripts.zip file as a version id, and Smart Connection only really
// downloads when the scripts to not yet exist or if they are outdated.
//
 